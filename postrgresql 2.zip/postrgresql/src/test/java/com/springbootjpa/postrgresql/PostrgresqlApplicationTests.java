package com.springbootjpa.postrgresql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostrgresqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
