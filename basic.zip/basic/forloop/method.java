// PNR details
import java.util.Scanner;


public class method
{
public static void main(String[] args)
{
long[] PNR 