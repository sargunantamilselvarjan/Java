abstract class Marks 
{
 abstract float getpercentage ();
}

class A extends Marks
{
private float marks1, marks2 , marks3;
public A (float m1, float m2, float m3)
	{
	marks1=m1;
	marks2=m2;
	marks3=m3;
	}
float getpercentage ( )
	{
	return ((marks1+marks2+marks3)/300)*100;
	}
}

class B extends Marks
{
private float marks1, marks2 , marks3, marks4;
public B (float m1, float m2, float m3, float m4)
	{
	marks1=m1;
	marks2=m2;
	marks3=m3;
	marks4=m4;
	}
 float getpercentage ()
	{
	return ((marks1+marks2+marks3+marks4)/400)*100;
	}
}
public class student
{
public static void main(String[] args)
	{
	A studentA = new A(50,50,50);
	B studentB = new B(60,60,60,60);
	System.out.println( "A student % " + studentA.getpercentage());
	System.out.println( "B student % "+ studentB.getpercentage());
	}
}