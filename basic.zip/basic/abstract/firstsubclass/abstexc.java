abstract class objabst 
{
	abstract void message ();
}
class Firstsubclass extends objabst {
	void message () 
	{
		System.out.println("this is first Subclass");
	}
}
class Secoundclass extends objabst {
	void message ()
	{
		System.out.println(" this is second subclass");
	}
}
public class abstexc {
	public static void main(String[] args)
	{
		objabst obj1 = new Firstsubclass();
		objabst obj2 = new Secoundclass();
		obj1.message();
		obj2.message();
		
	}
}