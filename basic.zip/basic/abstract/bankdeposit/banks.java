abstract class Bank 
{
	abstract void getbalance();
}
class BankA extends Bank
{
	void getbalance()
	{
		System.out.println("Bank A deposit = $100/-"); 
	}
}
class BankB extends Bank
{
	void getbalance()
	{
		System.out.println("Bank B deposit =$150/-");
	}
}
class BankC extends Bank
{
	void getbalance()
	{
		System.out.println("Bank C deposit =$200/-");
	}
}
public class banks 
{
	public static void main(String[] args)
	{
		Bank A= new BankA();	//calling the classBankA of ext Bank
		Bank B= new BankB();	//calling the classBankB of ext Bank
		Bank C= new BankC();	//calling the classBankc of ext Bank
		A.getbalance();		// return value of subclass
		B.getbalance();		// return value of subclass
		C.getbalance();		// return value of subclass
	}
}