// transport confirmation from tambram to madurai
import java.util.Scanner;


public class method
{
public static void main(String[] args)
{
	Scanner travel= new Scanner(System.in);
	String b="Bus", c="Car", t="Train", f="Flight", z="wrong";
	int pt=500, pb=800, pc=8000, pf=10000;
	System.out.println("Enter the Transport method \"Train\\Bus\\Flight\\Car\" for Chennai to Madurai");
	String way = travel.nextLine();
			if (way.equalsIgnoreCase(b))
			{
			System.out.println(" Fair for "+ b+" from Chennai to madurai Rs " + pb+ "//-");
			}
			else
			{
			if (way.equalsIgnoreCase(c))
			{
			System.out.println(" Fair for "+ c+" from Chennai to madurai Rs " + pc+ "//-");
			}
			else
			{
			if (way.equalsIgnoreCase(t))
			{
			System.out.println(" Fair for "+ t+" from Chennai to madurai Rs " + pt+ "//-");
			}
			else
			{
			if (way.equalsIgnoreCase(f))
			{
			System.out.println(" Fair for "+ f+" from Chennai to madurai Rs " + pf+ "//-");
			}
			else
			{
				System.out.println("enter correct Transport train/car/bus/flight");
			}
}
}
}
}
}
	
