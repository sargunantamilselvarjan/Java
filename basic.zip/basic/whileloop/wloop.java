// while loop for for decrease order 

import java.util.Scanner;
class wloop
{
public static void main(String[] args)
	{
	Scanner a = new Scanner(System.in);
	System.out.println(" enter the number of the day in week start 1 from Monday");
	int n= a.nextInt(); // no of days in a week
	do
	{
	
	System.out.println(n);
	n--;
	}
	while (n>=0);
}
}
	