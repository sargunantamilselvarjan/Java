// double carry to get 8 student mark and avg

import java.util.Scanner;
 
class doublearray
{
	public static void main(String[] args)
	{
		double avg,sum=0;
		double stud[][]= new double[8][3];
		Scanner sub= new Scanner(System.in);
		for (int n=0; n<8; n++)
		{
		for (int j=0; j<3; j++)
		{
		System.out.println("Enter "+ (j+1)+" subject mark"+(n+1)+" student");
		stud[n][j]= sub.nextDouble();
		sum=sum+stud[n][j];
		}
		avg=sum/3;
		System.out.println("average for "+(n+1)+" student :"+avg);
		avg=0;
		sum=0;
		}
	}
}