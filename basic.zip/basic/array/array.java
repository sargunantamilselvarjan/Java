// array for stud height and count
import java.util.Scanner


class Array
{
	public static void main(String[] args)
	{
	double sum=0, avg;
	Scanner s1= new Scanner(System.in);
	System.out.println("Enter number of student");
	int n=s1.nextInt();
	System.out.println("Height of student");
	for (int s=0; s<n; s++)
	{
	System.out.println("student " + (s+1)+":");
	double height=s1.nextDouble();
	sum=sum+height;
	}
	avg=sum/n;
	System.out.println("Average height :" + avg);
}
}