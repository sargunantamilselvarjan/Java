import java.util.Scanner;

public class scan
{
public static void main(String args[])
{
	Scanner in=new Scanner(System.in);
	System.out.println("enter number:");
int numb=in.nextInt();
if (numb%2==0)
{
System.out.println("Even");
}
else 
{
System.out.println("odd");
}
}
}