// overloading using method student

class student
{
	String name;
	public student (String s) //creating student method when input provide
	{
	name=s;
	}
	public student() // creating student method when no input
	{
	name="Unknown";
	}
}
class overload
{
	public static void main (String[] args)
	{
	student a= new student ("Yazhini");
	student b= new student ();
	System.out.println(a.name);
	System.out.println(b.name);
	}
}