package com.springbootjpa.postrgresql.model;



import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@JsonIgnoreProperties({"hibernateLazyInitializer"})

@Entity
@Table (name="book")
public class Book{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
 private long id;
	
 @Column(name="name")
 private String name;
 
 @Column(name = "publish-date")
 private Date publishdate;
 
 public Book() {
	 
 }
 public Book(String name,Date publish_date) {
	 this.name=name;
	 this.publishdate=publish_date;
	 
 }
 public long getId() {
	 return id;
 }
 public String getName() {
	 return name;
 }
 public void setName( String name) {
	 this.name=name;
 }
 public Date getPublishdate() {
	 return publishdate;
 }
 public Date setPublishdate(Date publish_date) {
	 return publishdate=publish_date;
	 
 }
 @Override
 public String toString() {
	 return "Book [id=" + id + ", name=" + name + ", publishdate =" + publishdate +"]";
 }
 
 
}
