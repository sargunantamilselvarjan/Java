package com.springbootjpa.postrgresql.controller;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springbootjpa.postrgresql.repository.BookRepository;
import com.springbootjpa.postrgresql.repository.AuthorRepository;
import com.springbootjpa.postrgresql.model.Author;
import com.springbootjpa.postrgresql.model.Book;
import com.springbootjpa.postrgresql.exception.ResourceNotFoundException;

@CrossOrigin(origins ="http://localhost:8081")
@RestController
@RequestMapping("/api")

public class AuthorController {
	
	@Autowired
	AuthorRepository authorRepository;
	
	@Autowired
	BookRepository bookRepository;
	
	@GetMapping("/author")
	public ResponseEntity<List<Author>>getAll(@RequestParam(required=false) String name){
		List <Author> author = new ArrayList<Author>();
		try
		{
			if (name == null)
			authorRepository.findAll().forEach(author ::add);
		else
			authorRepository.findByName(name).forEach(author::add);
		if (author.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity<>(author,HttpStatus.OK);
		}
	}catch (Exception e){
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	}
	
	@GetMapping("/author/{authorid}")
	public ResponseEntity<Author>getbyId(@PathVariable("authorid") long id){
		Author authordata=authorRepository.findById(id)
				.orElseThrow(() ->new ResourceNotFoundException("not found"+ id));
		return new ResponseEntity<>(authordata,HttpStatus.OK);
	}
	
	@PostMapping({"/book/{bookid}/author","book/author/{bookid}"})
	public ResponseEntity<Author>addAuthor(@PathVariable("bookid") Long bookId, @RequestBody Author authorRequest){
		try {
		Author author=bookRepository.findById(bookId).map(book-> 
		{
			long authorId=authorRequest.getId();
			//Author is existed
			if (authorId != 0L)
			{
				Author _author=authorRepository.findById(authorId).orElseThrow(()->  new ResourceNotFoundException ("not found tag id" + authorId));
				book.addAuthor(_author);
				bookRepository.save(book);
				return _author;
			}
			//add and create new Author
			book.addAuthor(authorRequest);
			return authorRepository.save(authorRequest);
		}).orElseThrow(() -> new ResourceNotFoundException ("not found bookid " + bookId));
		
		return new ResponseEntity <>(author,HttpStatus.CREATED);
		}catch (Exception e) {
			System.out.println("error");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/*	try{
			Author authordata=authorRepository
			.save(new Author (author.getName(),author.getEmailid(),author.getPhone(),author.getAddress()));
		return new ResponseEntity<>(authordata,HttpStatus.OK);
		}catch (Exception e) {
		return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/author")
	public ResponseEntity<Author>CreateAuthor(@RequestBody Author author){
		Author authordata=authorRepository.save(
				new Author(author.getAddress(),author.getEmailid(),author.getPhone(),author.getName()));
		return new ResponseEntity<>(authordata,HttpStatus.CREATED);
	}*/
	
	@PutMapping("/author/{authorid}")
	public ResponseEntity<Author>update(@PathVariable ("authorid") long id, @RequestBody Author author)
	{
		Author _authordata=authorRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("not Found"+id + "no"));
		_authordata.setEmailid(author.getEmailid());
		_authordata.setAddress(author.getAddress());
		_authordata.setPhone(author.getPhone());
		return new ResponseEntity<>(authorRepository.save(_authordata),HttpStatus.OK);
	}
	
	@DeleteMapping("/author/{authorid}")
	public ResponseEntity<HttpStatus>deletAuthor(@PathVariable("authorid") long id){
		try{
			authorRepository.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		
	@DeleteMapping("/author")
	public ResponseEntity<HttpStatus>deleteAllAuthor(){
		try{
			authorRepository.deleteAll();
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}catch (Exception e)
		{
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/book/{bookid}/author")
	public ResponseEntity<List<Author>>getAllAuthorsByBookId(@PathVariable("bookid")Long bookId)
	{
		if (!bookRepository.existsById(bookId)) {
			throw new ResourceNotFoundException( "no book available with thisID " + bookId);
		}
		List<Author> authors=authorRepository.findAuthorsByBooksId(bookId);
		return new ResponseEntity<>(authors,HttpStatus.OK);
	}
	
	@GetMapping("/book/author/{authorid}")
	public ResponseEntity<List<Book>>getAllBooksByAuthorId(@PathVariable("authorid")Long authorId)
	{
		if(!authorRepository.existsById(authorId)) {
			throw new ResourceNotFoundException("no authoravaibale with thisID "+ authorId);
		}
		List<Book> books=bookRepository.findBooksByAuthorsId(authorId);
		return new ResponseEntity<>(books,HttpStatus.OK);
		}
	
	@DeleteMapping("/book/{bookid}/author/{authorid}")
	public ResponseEntity<HttpStatus>deleteAuthorFromBook(@PathVariable ("bookid") long bookId,@PathVariable ("authorid") long authorId){
		Book book=bookRepository.findById(bookId).orElseThrow(()-> new ResourceNotFoundException ("not found bookid "+ bookId));
		book.removeAuthor(authorId);
		bookRepository.save(book);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
