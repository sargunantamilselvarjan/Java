package com.springbootjpa.postrgresql.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springbootjpa.postrgresql.model.Publisher;

public interface PublisherRepository extends JpaRepository<Publisher, Long> {

	List <Publisher> findByName( String Name);
	List <Publisher> findPublishersByBooksId(Long bookId);
}
