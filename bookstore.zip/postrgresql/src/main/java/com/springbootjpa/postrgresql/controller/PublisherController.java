package com.springbootjpa.postrgresql.controller;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springbootjpa.postrgresql.repository.BookRepository;
import com.springbootjpa.postrgresql.repository.PublisherRepository;
import com.springbootjpa.postrgresql.model.Book;
import com.springbootjpa.postrgresql.model.Publisher;
import com.springbootjpa.postrgresql.exception.ResourceNotFoundException;

@CrossOrigin(origins="http:\\localhost:8081")
@RestController
@RequestMapping("/api")

public class PublisherController {
	
	@Autowired
	PublisherRepository publisherRepository;
	
	@Autowired
	BookRepository bookRepository;
	
	@GetMapping("/publisher")
	public ResponseEntity<List<Publisher>>getAll(@RequestParam(required=false) String name)
	{
		List <Publisher> publisher =new ArrayList<Publisher>();
		try {
		if (name==null)
			publisherRepository.findAll().forEach(publisher::add);
		else
			publisherRepository.findByName(name).forEach(publisher::add);
		if (publisher.isEmpty())
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(publisher,HttpStatus.OK);
		}catch (Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

	@GetMapping("/publisher/{publisherid}")
	public ResponseEntity<Publisher>getbyId(@PathVariable("publisherid")long id)
	{
		Publisher publisherdata =publisherRepository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException ("not nound "+id));
		return new ResponseEntity<>(publisherdata,HttpStatus.OK);
	}
	
	@GetMapping("/book/{bookid}/publisher")
	public ResponseEntity<List<Publisher>>getAllPublishersByBookId(@PathVariable("bookid")Long bookId)
	{
		if (!bookRepository.existsById(bookId)) {
		throw new ResourceNotFoundException("not found the bookid "+ bookId);
	}
	List<Publisher> publiserdetails=publisherRepository.findPublishersByBooksId(bookId);
	return new ResponseEntity<>(publiserdetails,HttpStatus.OK);
	}
	
	@GetMapping("/book/publisher/{publisherid}")
	public ResponseEntity<List<Book>>getAllBooksbyPublisherId(@PathVariable ("publisherid")Long publisherId)
	{
		if(!publisherRepository.existsById(publisherId)) {
			throw new ResourceNotFoundException("not found the publisher id "+ publisherId); 
		}
	List<Book> bookdetails=bookRepository.findBooksByAuthorsId(publisherId);
	return new ResponseEntity<>(bookdetails,HttpStatus.OK);
	}
	
	@PostMapping({"/book/{bookid}/publisher","/book/publisher/{bookid}"})
	public ResponseEntity<Publisher>addPublisher(@PathVariable("bookid")Long bookId,@RequestBody Publisher publisher)
	{
		try {
	Publisher publisherdata=bookRepository.findById(bookId).map(bookdata->{
		long publisherId=publisher.getId();
		// publisher is Exist
		if (publisherId != 0L)
		{
			Publisher _data=publisherRepository.findById(publisherId)
					.orElseThrow(()-> new ResourceNotFoundException (" no Id "+ bookId));
			bookdata.addPublisher(_data);
			bookRepository.save(bookdata);
			return _data;
		}
		// add or create new Publisher
		bookdata.addPublisher(publisher);
		return publisherRepository.save(publisher);
	}).orElseThrow(()-> new ResourceNotFoundException ("not found bookid "+ bookId));
	
	return new ResponseEntity <>(publisherdata,HttpStatus.CREATED);
		}catch (Exception e) {
			System.out.println("error");
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	
	}
	
	@PutMapping("/publisher/{publisherid}")
	public ResponseEntity<Publisher>update(@PathVariable("publisherid") long publisherId, @RequestBody Publisher publisher)
	{
		try{
			Publisher _publisherdata=publisherRepository.findById(publisherId)
					.orElseThrow(() -> new ResourceNotFoundException ("not found publisherdata "+ publisherId + "not"));
				
					//.map(data-> {publisher.setBooks(data);return publisherRepository.save(publiser);
						//publisher.getAddress();publisher.getEmailid();publisher.getName();publisher.getPhonenumber();}
	_publisherdata.setEmailid(publisher.getEmailid());
		_publisherdata.setPhonenumber(publisher.getPhonenumber());
		_publisherdata.setAddress(publisher.getAddress());
		return new ResponseEntity<>(publisherRepository.save(_publisherdata),HttpStatus.ACCEPTED);
		}catch (Exception e) {
			System.out.println("error");
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/publisher")
	public ResponseEntity<HttpStatus>deleteAllPublisher(){
		publisherRepository.deleteAll();
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/publisher/{publisherid}")
	public ResponseEntity<HttpStatus>deletePublisher(@PathVariable("publisherid")long id)
	{
		publisherRepository.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/book/{bookid}/publisher/{publisherid}")
	public ResponseEntity<HttpStatus>deletePublisherFromBook(@PathVariable ("bookid") long bookId, @PathVariable("publisherid") long publisherId){
		Book book=bookRepository.findById(bookId).orElseThrow(() -> new ResourceNotFoundException ("not found bookid " + bookId));
		book.removePublisher(publisherId);
		bookRepository.save(book);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	
}
