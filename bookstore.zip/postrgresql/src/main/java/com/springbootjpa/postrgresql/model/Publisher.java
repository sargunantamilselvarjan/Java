package com.springbootjpa.postrgresql.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name ="publisher")
public class Publisher {
	
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
private long id;

@Column (name ="name")
private String name;

@Column (name="phone_number")
private long phonenumber;

@Column (name="email_id")
private String emailid;

@Column (name="address")
private String address;

@ManyToMany(fetch=FetchType.LAZY, cascade= {CascadeType.PERSIST,CascadeType.MERGE},mappedBy="publishers")
@JsonIgnore
private Set<Book> books=new HashSet<>();

public Publisher() {
	
}
public Publisher (String name, String emailid, String address, long phonenumber)
{
this.name=name;
this.emailid=emailid;
this.address=address;
this.phonenumber=phonenumber;

}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(long phonenumber) {
	this.phonenumber = phonenumber;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Set<Book> getBooks() {
	return books;
}
public void setBooks(Set<Book> books) {
	this.books = books;
}


}
