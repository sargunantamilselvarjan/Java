package com.springbootjpa.postrgresql.model;

import java.util.Set;
import java.util.HashSet;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table (name="author")
public class Author{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="author_id")
	private long id;
	
	@Column (name="name")
	private String name;
	
	@Column (name="email_id")
	private String emailid;
	
	@Column (name="phone#")
	private long phone;
	
	@Column (name="address")
	private String address;
	
	@ManyToMany (fetch=FetchType.LAZY,cascade = {CascadeType.PERSIST,CascadeType.MERGE},mappedBy="authors" )
	@JsonIgnore
	private Set<Book> books=new HashSet<>();
	
	public Author() {
		
	}
	
	public Author(String name,String emailid, long phone, String address)
	{
		this.name=name;
		this.address=address;
		this.emailid=emailid;
		this.phone=phone;		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	
	/*public Set<Book> getBook(){
		return books;
	}
	
	public void setBook(Set<Book> book) {
		this.books= book;
	}*/
	
}